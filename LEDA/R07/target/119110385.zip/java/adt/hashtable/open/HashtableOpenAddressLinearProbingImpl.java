package adt.hashtable.open;

import adt.hashtable.hashfunction.HashFunctionClosedAddressMethod;
import adt.hashtable.hashfunction.HashFunctionLinearProbing;
import adt.hashtable.hashfunction.HashFunctionOpenAddress;

public class HashtableOpenAddressLinearProbingImpl<T extends Storable> extends
		AbstractHashtableOpenAddress<T> {

	public HashtableOpenAddressLinearProbingImpl(int size,
			HashFunctionClosedAddressMethod method) {
		super(size);
		hashFunction = new HashFunctionLinearProbing<T>(size, method);
		this.initiateInternalTable(size);
	}

	@Override
	public void insert(T element) {
		if (element == null) return;
		if (elements >= capacity() && indexOf(element) == -1) throw new HashtableOverflowException();
		HashFunctionOpenAddress<T> hashFunc = ((HashFunctionOpenAddress<T>) getHashFunction());
		int probe = 0;
		int hashElement = hashFunc.hash(element, probe)%capacity();
		while (true) {
			// Se achar um lugar vazio.
			if (table[hashElement] == null || table[hashElement] == deletedElement) {
				table[hashElement] = element;
				COLLISIONS += probe;
				elements++;
				break;
			}
			// Se achar o pr�prio valor na lista, atualiza.
			else if (table[hashElement].equals(element)) {
				table[hashElement] = element;
				break;
			}
			// Se n�o, continua, agora adicionando +1 no probe.
			else hashElement = hashFunc.hash(element, ++probe)%capacity();
		}
	}

	@Override
	public void remove(T element) {
		// Se tentar remover um elemento null, nem procura.
		if (element == null) return;
		// Procura pelo elemento.
		int index = indexOf(element);
		// Se n�o tiver achado, apenas para a fun��o.
		if (index == -1) return;
		// Se achou, seta o elemento como deleted e diminui a variavel elements.
		table[index] = deletedElement;
		elements--;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T search(T element) {
		// Procura pelo indice do elemento.
		int index = indexOf(element);
		// Se n�o tiver achado, retorna null.
		if (index == -1) return null;
		// Se tiver achado, retorna o elemento da tabela.
		return (T) table[index];
	}

	@Override
	public int indexOf(T element) {
		if (element == null) return -1;
		if (capacity() == 0) return -1;
		HashFunctionOpenAddress<T> hashFunc = ((HashFunctionOpenAddress<T>) getHashFunction());
		int probe = 0;
		int hashElement = hashFunc.hash(element, probe)%capacity();
		int firstHash = hashElement;
		while (true) {
			// Se tiver hash tiver retornado ao inicio sem achar ele para.
			if (probe != 0 && firstHash == hashElement) return -1;
			if (probe > capacity()) return -1;
			// Se achar um null, significa que n�o h� mais como ter elementos desse mesmo hash na frente e portanto pode parar.
			if (table[hashElement] == null) return -1;
			// Se achar o elemento.
			else if (table[hashElement].equals(element)) return hashElement;
			// Se n�o achar, e n�o for condi��o de parada, continua procurando.
			else hashElement = hashFunc.hash(element, ++probe)%capacity();
		}
	}

}
